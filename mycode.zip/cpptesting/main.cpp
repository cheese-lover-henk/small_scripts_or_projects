#include "types.h"

#include "window.h"
#include "engine.h"

int main() {
    
    // start window thread
    
    rwQueue<WindowEvent> eq(100);   //1p1c, window is producer, engine is consumer.
    rwQueue<WindowCommand> cq(100); //1p1c, engine is producer, window is consumer.
    FrameBufferManager v;
    v.init();
    
    std::thread windowThread([&] {
        Window window;
        window.create(1920, 1080, "Window", false);
        window.setWindowEventQueuePtr(&eq);
        window.setWindowCommandQueuePtr(&cq);
        window.setFrameBufferManager(&v);
        window.startMessageLoop();
    });
    
    std::thread engineThread([&] {
        Engine engine;
        engine.setTargetFPS(240);
        engine.setWindowEventQueuePtr(&eq);
        engine.setWindowCommandQueuePtr(&cq);
        engine.setFrameBufferManager(&v);
        engine.startMainLoop();
    });
    
    engineThread.join();
    windowThread.join();
    return 0;
}
